Readme Guide for Associates:

1. The CCJP_Casestudy_Guide.ppsx gives the step by step guide to approach the CCJP assessment. Associate can go through this guide before they start the Practice/Sample case studies.

2. Next, the associate can implement the CCJP_Practice_Casestudy_Payroll_system which contains a plenty of APIs and scenarios for the associate to practice. This is just a case study for practicing the Core Java skills.
Note: The associate can seek the help of peers/trainers to solve this case study. 
Use the PayRollManager_Skeleton_File for implementing this case study.

